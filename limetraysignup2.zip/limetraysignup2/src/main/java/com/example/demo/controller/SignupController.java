package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Admin;
import com.example.demo.services.Signupservice;


@Controller
@ResponseBody
public class SignupController {

	@Autowired
	Signupservice service;

	
	
	@GetMapping("/signup2")
	public ModelAndView myMethod() {
		System.out.println("get users");
		ArrayList<Admin> user=new ArrayList<Admin>();
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("signup2");
		user=service.display();
		System.out.println(user);
		modelandview.addObject("user", user);
		return modelandview;
	}
}

	
	
	