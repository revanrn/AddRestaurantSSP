package com.example.demo.model;

public class Admin {
String Name;
@Override
public String toString() {
	return "admin [Name=" + Name + ", UserId=" + UserId + ", Phone=" + Phone + ", Email=" + Email + "]";
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getUserId() {
	return UserId;
}
public void setUserId(String userId) {
	UserId = userId;
}
public String getPhone() {
	return Phone;
}
public void setPhone(String phone) {
	Phone = phone;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
String UserId;
String Phone;
String Email;

}
