package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Admin;

@Repository

public class SignupDAO {

	public static Connection connectToDB() {
		Connection connection = null;
		try {
			// STEP - 1 : Register the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// STEP - 2 Connecting with oracle database
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		}

		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<Admin> displayUser() {
		ArrayList<Admin> userList = new ArrayList<Admin>();
		try {
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("select * from signup");
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next())
			{
				Admin user = new Admin();
                     user.setName(rs.getString(1));
                     user.setUserId(rs.getString(2));
                     user.setPhone(rs.getString(3));
                     user.setEmail(rs.getString(4));
                     
				userList.add(user);
			}
			// Step 5:Close Connection
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return userList;

	}
}

