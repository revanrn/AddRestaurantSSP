package com.example.demo.dao;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;

	import org.springframework.stereotype.Repository;

	import com.example.demo.model.Location;


	@Repository

	public class LocationDAO {

		public static Connection connectToDB() {
			Connection connection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return connection;

		}

		public String addUser(Location loc) { try {
			 Connection con = connectToDB(); PreparedStatement stmt =
			  con.prepareStatement("insert into location values(?,?,?,?,?,?,?,?,?,?,?,?)");
			  stmt.setString(1, loc.getRouteId()); stmt.setString(2, loc.getFrom());
			 stmt.setString(3, loc.getTo()); stmt.setString(4, loc.getFromTime());
			  stmt.setString(5, loc.getToTime()); stmt.setString(6, loc.getStop1());
			  stmt.setString(7, loc.getStop2()); stmt.setString(8, loc.getStop3());
			  stmt.setString(9, loc.getTime1()); stmt.setString(10, loc.getTime2());
			  stmt.setString(11, loc.getTime3()); stmt.setString(12, loc.getTrainNo());
			  
			  // Step 4: Execute SQL Query 
			  int affectedRows = stmt.executeUpdate();
			  System.out.println("Affected rows " + affectedRows);
			  
			  // Step 5:Close Connection con.close();
			  
			  } catch (SQLException e) { // TODO Auto-generated catch block
			  e.printStackTrace(); }
			  return "data inserted successfully";
			  }
			 
              

		
		
		
		
		
		
		
		
		
		
		
}
